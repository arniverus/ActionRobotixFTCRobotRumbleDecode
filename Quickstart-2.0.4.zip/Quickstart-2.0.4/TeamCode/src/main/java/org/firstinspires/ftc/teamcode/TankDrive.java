package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;

@TeleOp
public class TankDrive extends OpMode {

    // Drive Motors
    DcMotor frontLeft, frontRight, backLeft, backRight;

    // Mechanism Motors
    DcMotor spinner;

    // CRServos for intake
    CRServo leftServo, rightServo;

    // Variables
    double driveDivisor = 1;
    double driveMultiplier = 1.0; // Added for slow/normal control
    final double TPR = 537.7;  // Ticks per revolution for arm motor
    int position;

    // Toggles (currently unused, but kept)
    boolean squarePressed = false;
    boolean toggleState = false;
    boolean actionInProgress = false;

    // Timer
    ElapsedTime timer = new ElapsedTime();

    @Override
    public void init() {
        // Initialize motors
        frontLeft = hardwareMap.get(DcMotor.class, "frontLeft");
        frontRight = hardwareMap.get(DcMotor.class, "frontRight");
        backLeft = hardwareMap.get(DcMotor.class, "backLeft");
        backRight = hardwareMap.get(DcMotor.class, "backRight");
        spinner = hardwareMap.get(DcMotor.class, "spinner");

        // Initialize servos
        leftServo = hardwareMap.get(CRServo.class, "leftServo");
        rightServo = hardwareMap.get(CRServo.class, "rightServo");

        // Reverse left side drive motors (Standard for tank drive)
        frontLeft.setDirection(DcMotorSimple.Direction.REVERSE);
        backLeft.setDirection(DcMotorSimple.Direction.REVERSE);
    }

    @Override
    public void loop() {

        // --- Tank Drive Power Calculation ---
        // FIX: Both sticks must be inverted since 'up' on the stick is a negative value in the API
        // .
        double x = gamepad1.left_stick_x * 1.1;  // strafe compensation
        double turn = gamepad1.right_stick_x;
        double leftPower = -gamepad1.left_stick_y / driveDivisor;
        double rightPower = -gamepad1.right_stick_y / driveDivisor;
        double spinnerPower = -gamepad2.right_stick_y;

        // Cubic scaling for smoother control
        leftPower = Math.pow(leftPower, 3);
        rightPower = Math.pow(rightPower, 3);

        // --- Speed Control ---
        if (gamepad1.a) {
            driveMultiplier = 0.5; // Slow Mode
        } else if (gamepad1.b) {
            driveMultiplier = 1.0; // Normal Mode
        }


        // If neither is pressed, the multiplier stays at its last set value (default 1.0)


        // Apply power with multiplier
        frontLeft.setPower(leftPower * driveMultiplier);
        backLeft.setPower(leftPower * driveMultiplier);
        frontRight.setPower(rightPower * driveMultiplier);
        backRight.setPower(rightPower * driveMultiplier);
        spinner.setPower(spinnerPower);
        if(gamepad2.x) {
            spinner.setPower(spinnerPower /.5);
        }
        else {
            spinner.setPower(spinnerPower);
        }
        // --- Intake Control ---
        if (gamepad1.x) {
            leftServo.setPower(-1); // In
            rightServo.setPower(1);  // In
        } else if (gamepad1.y) {
            leftServo.setPower(1);  // Out
            rightServo.setPower(-1); // Out
        } else {
            leftServo.setPower(0);
            rightServo.setPower(0);
        }

        // --- Arm Control (Encoder-Based) ---
        // (No code here yet)


        // Optional: Show current arm angle


    } // This is the correct closing brace for the loop() method

    // Move arm to a specific degree using encoder


    // Simple sleep method (used in strafing)
    public void sleep(int time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // Optional: Add strafe methods if needed
    public void strafeLeft(float power, int time) {
        frontLeft.setPower(-power);
        frontRight.setPower(power);
        backLeft.setPower(power);
        backRight.setPower(-power);
        sleep(time);
        stopDrive();
    }

    public void strafeRight(float power, int time) {
        frontLeft.setPower(power);
        frontRight.setPower(-power);
        backLeft.setPower(-power);
        backRight.setPower(power);
        sleep(time);
        stopDrive();
    }


    public void stopDrive() {
        frontLeft.setPower(0);
        frontRight.setPower(0);
        backLeft.setPower(0);
        backRight.setPower(0);
    }
}