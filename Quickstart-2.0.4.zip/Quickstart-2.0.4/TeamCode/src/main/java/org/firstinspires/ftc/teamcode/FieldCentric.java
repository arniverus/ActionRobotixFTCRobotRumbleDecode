package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.bosch.BHI260IMU;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;

@TeleOp
public class FieldCentric extends OpMode {

    DcMotor frontLeft, frontRight, backLeft, backRight;

    DcMotor spinner;
    CRServo leftServo, rightServo;


    double driveMultiplier = 1.0;


    BHI260IMU imu;


    ElapsedTime timer = new ElapsedTime();

    @Override
    public void init() {

        // Initialize motors
        frontLeft = hardwareMap.get(DcMotor.class, "frontLeft");
        frontRight = hardwareMap.get(DcMotor.class, "frontRight");
        backLeft = hardwareMap.get(DcMotor.class, "backLeft");
        backRight = hardwareMap.get(DcMotor.class, "backRight");
        spinner = hardwareMap.get(DcMotor.class, "spinner");

        // Initialize intake servos
        leftServo = hardwareMap.get(CRServo.class, "leftServo");
        rightServo = hardwareMap.get(CRServo.class, "rightServo");

        // Reverse left drivetrain
        frontLeft.setDirection(DcMotorSimple.Direction.REVERSE);
        backLeft.setDirection(DcMotorSimple.Direction.REVERSE);

        // --- BHI260 IMU INITIALIZATION ---
        imu = hardwareMap.get(BHI260IMU.class, "imu");
        imu.initialize();

        telemetry.addData("Status", "Initialized (BHI260 IMU active)");
    }

    @Override
    public void loop() {


        double y = -gamepad1.left_stick_y;
        double x = gamepad1.left_stick_x * 1.1;
        double turn = -gamepad1.right_stick_x;

        // Read yaw using correct API for BHI260
        YawPitchRollAngles orientation = imu.getRobotYawPitchRollAngles();
        double heading = orientation.getYaw(AngleUnit.RADIANS);

        // Rotate movement to field-centric
        double rotX = x * Math.cos(heading) - y * Math.sin(heading);
        double rotY = x * Math.sin(heading) + y * Math.cos(heading);

        // Cubic smoothing
        rotX = Math.pow(rotX, 3);
        rotY = Math.pow(rotY, 3);
        turn = Math.pow(turn, 3);

        // Speed scaling
        if (gamepad1.a) driveMultiplier = 0.5;
        if (gamepad1.b) driveMultiplier = 1.0;


        double fl = (rotY + rotX + turn) * driveMultiplier;
        double fr = (rotY - rotX - turn) * driveMultiplier;
        double bl = (rotY - rotX + turn) * driveMultiplier;
        double br = (rotY + rotX - turn) * driveMultiplier;

        // Normalize
        double max = Math.max(1.0,
                Math.max(Math.abs(fl),
                        Math.max(Math.abs(fr),
                                Math.max(Math.abs(bl), Math.abs(br)))));

        frontLeft.setPower(fl / max);
        frontRight.setPower(fr / max);
        backLeft.setPower(bl / max);
        backRight.setPower(br / max);


        double spinnerPower = -gamepad2.right_stick_y;
        if (gamepad2.x) spinner.setPower(spinnerPower / 0.5);
        else spinner.setPower(spinnerPower);


        if (gamepad1.x) {
            leftServo.setPower(-1);
            rightServo.setPower(1);
        } else if (gamepad1.y) {
            leftServo.setPower(1);
            rightServo.setPower(-1);
        } else {
            leftServo.setPower(0);
            rightServo.setPower(0);
        }
    }

    public void stopDrive() {
        frontLeft.setPower(0);
        frontRight.setPower(0);
        backLeft.setPower(0);
        backRight.setPower(0);
    }
}
