package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.bosch.BHI260IMU;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;

@TeleOp
public class RobotCentric extends OpMode {

    DcMotor frontLeft, frontRight, backLeft, backRight;

    DcMotor spinner;
    CRServo leftServo, rightServo;

    double driveMultiplier = 1.0;

    BHI260IMU imu;

    ElapsedTime timer = new ElapsedTime();

    @Override
    public void init() {

        // Initialize motors
        frontLeft = hardwareMap.get(DcMotor.class, "frontLeft");
        frontRight = hardwareMap.get(DcMotor.class, "frontRight");
        backLeft = hardwareMap.get(DcMotor.class, "backLeft");
        backRight = hardwareMap.get(DcMotor.class, "backRight");
        spinner = hardwareMap.get(DcMotor.class, "spinner");

        // Initialize intake servos
        leftServo = hardwareMap.get(CRServo.class, "leftServo");
        rightServo = hardwareMap.get(CRServo.class, "rightServo");

        // Reverse left drivetrain
        frontLeft.setDirection(DcMotorSimple.Direction.REVERSE);
        backLeft.setDirection(DcMotorSimple.Direction.REVERSE);

        // IMU init (still here but unused for driving)
        imu = hardwareMap.get(BHI260IMU.class, "imu");
        imu.initialize();

        telemetry.addData("Status", "Initialized (Robot-Centric)");
    }

    @Override
    public void loop() {

        // --- ROBOT-CENTRIC CONTROLS ---
        double y = -gamepad1.left_stick_y;
        double x = gamepad1.left_stick_x * 1.1;
        double turn = -gamepad1.right_stick_x;

        // Cubic smoothing (same as your FC version)
        x = Math.pow(x, 3);
        y = Math.pow(y, 3);
        turn = Math.pow(turn, 3);

        // Speed scaling
        if (gamepad1.a) driveMultiplier = 0.5;
        if (gamepad1.b) driveMultiplier = 1.0;

        // Standard robot-centric mecanum math
        double fl = (y + x + turn) * driveMultiplier;
        double fr = (y - x - turn) * driveMultiplier;
        double bl = (y - x + turn) * driveMultiplier;
        double br = (y + x - turn) * driveMultiplier;

        // Normalize
        double max = Math.max(1.0,
                Math.max(Math.abs(fl),
                        Math.max(Math.abs(fr),
                                Math.max(Math.abs(bl), Math.abs(br)))));

        frontLeft.setPower(fl / max);
        frontRight.setPower(fr / max);
        backLeft.setPower(bl / max);
        backRight.setPower(br / max);

        // Spinner system
        double spinnerPower = -gamepad2.right_stick_y;
        if (gamepad2.x) spinner.setPower(spinnerPower / 5);
        else {
            spinner.setPower(spinnerPower);
        }


        // Intake servos
        if (gamepad1.x) {
            leftServo.setPower(-1);
            rightServo.setPower(1);
        } else if (gamepad1.y) {
            leftServo.setPower(1);
            rightServo.setPower(-1);
        } else {
            leftServo.setPower(0);
            rightServo.setPower(0);
        }
    }

    public void stopDrive() {
        frontLeft.setPower(0);
        frontRight.setPower(0);
        backLeft.setPower(0);
        backRight.setPower(0);
    }
}
